// Notcoin V7 final script: polished silver icons, glass buy buttons, vibration on click & buy, share, referral logic
(() => {
  const el = id => document.getElementById(id);
  const fmt = n => n.toLocaleString('en-US');

  const state = {
    coins: 0,
    total: 0,
    clickValue: 1,
    energy: 24,
    energyMax: 6000,
    incomePerSec: 0,
    referrals: 0,
    lastTick: Date.now(),
    soundOn: true
  };

  const ITEMS = [
    {id:'miner', name:'Miner', cost:150, cps:0.12, icon:'⛏️'},
    {id:'farm', name:'Farm', cost:1200, cps:1.2, icon:'🏭'},
    {id:'rig', name:'Rig', cost:15000, cps:14, icon:'🖥️'}
  ];
  const BOOSTS = [
    {id:'doubleClick', name:'Double Click', cost:5000, effect: s=> s.clickValue *= 2},
    {id:'autoMine', name:'Auto Mine', cost:20000, effect: s=> s.incomePerSec += 5}
  ];

  // DOM refs
  const balanceNum = el('balance-num'), bigBalance = el('bigBalance'), energyNum = el('energy-num'),
        energyMax = el('energy-max'), coinWrap = el('coinWrap'), goldCoin = el('goldCoin'),
        particles = el('particles'), shopEl = el('shop'), boostShopEl = el('boostShop'),
        refLink = el('refLink'), refCount = el('refCount'), shareBtn = el('shareBtn'),
        soundToggle = el('soundToggle'), exportBtn = el('exportBtn'), importBtn = el('importBtn');

  // audio
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  const audioCtx = AudioCtx ? new AudioCtx() : null;
  function playClickSound(){
    if(!audioCtx || !state.soundOn) return;
    const o = audioCtx.createOscillator(), g = audioCtx.createGain();
    o.type='sine'; o.frequency.value = 700;
    g.gain.value = 0.0001;
    o.connect(g); g.connect(audioCtx.destination);
    const now = audioCtx.currentTime;
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(0.08, now + 0.02);
    o.frequency.exponentialRampToValueAtTime(300, now + 0.12);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.18);
    o.start(now); o.stop(now + 0.18);
  }

  function fmtNum(n){ return Math.floor(n).toLocaleString('en-US'); }

  // particles
  function burst(x,y){
    for(let i=0;i<12;i++){
      const p = document.createElement('div');
      p.style.position='absolute'; p.style.left = x + 'px'; p.style.top = y + 'px';
      p.style.width = p.style.height = (6+Math.random()*10) + 'px';
      p.style.background = Math.random()>0.5 ? 'rgba(255,215,50,0.95)' : 'rgba(255,255,255,0.85)';
      p.style.borderRadius='50%'; p.style.pointerEvents='none';
      particles.appendChild(p);
      const dx = (Math.random()-0.5)*220; const dy = (Math.random()-0.8)*220 - 40;
      p.animate([{transform:'translate(0,0) scale(1)', opacity:1},{transform:`translate(${dx}px, ${dy}px) scale(0.3)`, opacity:0}], {duration:700+Math.random()*400, easing:'cubic-bezier(.2,.9,.3,1)'});
      setTimeout(()=>p.remove(), 1300);
    }
  }

  // referral id
  function myId(){ let id = localStorage.getItem('my_id_v7'); if(!id){ id = Math.random().toString(36).slice(2); localStorage.setItem('my_id_v7', id);} return id; }
  function myRefLink(){ return window.location.origin + window.location.pathname + '?ref=' + myId(); }

  // check referral awarding visitor once per ref (local)
  function checkReferral(){
    const params = new URLSearchParams(window.location.search);
    if(params.has('ref')){
      const ref = params.get('ref');
      const usedKey = 'ref_used_v7_' + ref;
      if(!localStorage.getItem(usedKey) && ref !== myId()){
        state.coins += 100000;
        state.total += 100000;
        localStorage.setItem(usedKey, '1');
        // increment local counter for inviter on THIS device only (demo)
        const key = 'ref_count_v7_' + ref;
        const cur = parseInt(localStorage.getItem(key) || '0',10);
        localStorage.setItem(key, String(cur+1));
        if(navigator.vibrate) navigator.vibrate(200);
        showTemp('+100,000 монет за реферера! (посетителю)');
      }
    }
  }

  function load(){ const raw = localStorage.getItem('notcoin_v7'); if(raw) Object.assign(state, JSON.parse(raw)); const rc = parseInt(localStorage.getItem('ref_count_v7_' + myId())||'0',10); state.referrals = rc || 0; }
  function save(){ localStorage.setItem('notcoin_v7', JSON.stringify(state)); localStorage.setItem('ref_count_v7_' + myId(), String(state.referrals || 0)); }

  function render(){
    balanceNum.innerText = fmtNum(state.coins);
    bigBalance.innerText = fmtNum(state.coins);
    energyNum && (energyNum.innerText = Math.floor(state.energy));
    refLink.innerText = myRefLink();
    refCount.innerText = state.referrals || 0;
    // shops
    if(shopEl){ shopEl.innerHTML = ''; ITEMS.forEach(it=>{
      const owned = (state.items && state.items[it.id] && state.items[it.id].owned) || 0;
      const div = document.createElement('div'); div.className='item';
      div.innerHTML = `<div class="left"><div class="icon">${it.icon}</div><div class="meta"><strong>${it.name}</strong><div class="small">+${it.cps}/сек</div></div></div>
        <div class="actions"><div class="price">${fmtNum(it.cost)}</div><button class="buy" data-buy="${it.id}">Купить</button><div style="font-size:12px;color:#9fb3c4">Owned: ${owned}</div></div>`;
      shopEl.appendChild(div);
    }); }
    if(boostShopEl){ boostShopEl.innerHTML = ''; BOOSTS.forEach(b=>{
      const div = document.createElement('div'); div.className='item';
      div.innerHTML = `<div class="left"><div class="icon">✨</div><div class="meta"><strong>${b.name}</strong></div></div>
        <div class="actions"><div class="price">${fmtNum(b.cost)}</div><button class="buy" data-boost="${b.id}">Купить</button></div>`;
      boostShopEl.appendChild(div);
    }); }
  }

  function showTemp(txt){
    const m = document.createElement('div');
    m.style.position='fixed'; m.style.left='50%'; m.style.top='12%'; m.style.transform='translateX(-50%)';
    m.style.padding='10px 14px'; m.style.background='linear-gradient(90deg,#ffd36a,#f7a800)'; m.style.color='#000';
    m.style.borderRadius='10px'; m.style.fontWeight='800'; document.body.appendChild(m);
    m.innerText = txt; setTimeout(()=> m.remove(),2200);
  }

  // click coin
  coinWrap.addEventListener('click', (ev)=>{
    if(state.energy <= 0){ showTemp('Нет энергии'); return; }
    state.coins += state.clickValue; state.total += state.clickValue; state.energy = Math.max(0, state.energy - 1);
    if(navigator.vibrate) navigator.vibrate(30);
    if(audioCtx && state.soundOn) playClickSound();
    const rect = coinWrap.getBoundingClientRect(); const x = ev.clientX - rect.left; const y = ev.clientY - rect.top;
    burst(x,y);
    goldCoin.style.transform = 'scale(.97) rotate(-6deg)'; setTimeout(()=> goldCoin.style.transform = '', 140);
    render(); save();
  });

  // shop buy handlers with vibration & sound & glass-button effect
  document.addEventListener('click', (e)=>{
    if(e.target.matches('[data-buy]')){
      const id = e.target.dataset.buy; const it = ITEMS.find(x=>x.id===id);
      if(!it) return;
      if(state.coins >= it.cost){ state.coins -= it.cost; state.items = state.items||{}; state.items[id] = state.items[id]||{owned:0}; state.items[id].owned++; state.incomePerSec += it.cps;
        if(navigator.vibrate) navigator.vibrate(70); if(audioCtx && state.soundOn) playClickSound(); showTemp(`Куплено ${it.name}`); render(); save();
      } else showTemp('Недостаточно монет');
    } else if(e.target.matches('[data-boost]')){
      const id = e.target.dataset.boost; const b = BOOSTS.find(x=>x.id===id);
      if(!b) return;
      if(state.coins >= b.cost){ state.coins -= b.cost; b.effect(state); state.boosts = state.boosts||{}; state.boosts[id]=true; if(navigator.vibrate) navigator.vibrate(80); if(audioCtx && state.soundOn) playClickSound(); showTemp(`Буст: ${b.name}`); render(); save(); } else showTemp('Недостаточно монет');
    }
  });

  // tabs
  document.querySelectorAll('.tab').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('.tab').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      const t = btn.dataset.tab;
      document.querySelectorAll('.tab-pane').forEach(p=> p.style.display = p.id === t ? 'block' : 'none');
    });
  });

  // share button
  const shareBtnEl = document.getElementById('shareBtn');
  shareBtnEl.addEventListener('click', async ()=>{
    const link = myRefLink();
    try{ if(navigator.share){ await navigator.share({title:'Join Notcoin', text:'Play Notcoin-inspired', url:link}); } else { await navigator.clipboard.writeText(link); showTemp('Ссылка скопирована'); } }catch(e){ showTemp('Не удалось поделиться'); }
  });

  // export/import
  const modal = document.getElementById('modal'), modalText = document.getElementById('modalText'), doImport = document.getElementById('doImport'), doClose = document.getElementById('doClose');
  exportBtn && exportBtn.addEventListener('click', ()=>{ const data = btoa(unescape(encodeURIComponent(JSON.stringify(state)))); modal.style.display='flex'; modalText.value = data; });
  importBtn && importBtn.addEventListener('click', ()=>{ modal.style.display='flex'; modalText.value=''; });
  doClose && doClose.addEventListener('click', ()=> modal.style.display='none');
  doImport && doImport.addEventListener('click', ()=>{ try{ const raw = modalText.value.trim(); if(!raw) return alert('Вставьте строку'); const parsed = JSON.parse(decodeURIComponent(escape(atob(raw)))); Object.assign(state, parsed); modal.style.display='none'; save(); render(); alert('Импорт успешен'); }catch(e){ alert('Ошибка импорта'); } });

  // sound toggle
  soundToggle && soundToggle.addEventListener('click', ()=>{ state.soundOn = !state.soundOn; render(); save(); });

  // referral check (award visitor once)
  checkReferral = checkReferral || (()=>{});
  (function(){ const params = new URLSearchParams(window.location.search); if(params.has('ref')){ const ref = params.get('ref'); const usedKey = 'ref_used_v7_' + ref; if(!localStorage.getItem(usedKey) && ref !== myId()){ state.coins += 100000; state.total += 100000; localStorage.setItem(usedKey,'1'); const key = 'ref_count_v7_' + ref; const cur = parseInt(localStorage.getItem(key)||'0',10); localStorage.setItem(key,String(cur+1)); if(navigator.vibrate) navigator.vibrate(200); showTemp('+100,000 монет (посетителю)'); } } })();

  function myId(){ let id = localStorage.getItem('my_id_v7'); if(!id){ id = Math.random().toString(36).slice(2); localStorage.setItem('my_id_v7', id);} return id; }
  function myRefLink(){ return window.location.origin + window.location.pathname + '?ref=' + myId(); }

  // tick
  function tick(){
    const now = Date.now(); const dt = (now - state.lastTick)/1000; state.lastTick = now;
    state.coins += state.incomePerSec * dt; state.total += state.incomePerSec * dt;
    state.energy = Math.min(state.energyMax, state.energy + dt*0.2);
    render(); save();
  }
  load(); render(); setInterval(tick,1000);

})();